class NeuralBridge:
    pass
