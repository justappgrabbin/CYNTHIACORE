class CIBridge:
    pass
