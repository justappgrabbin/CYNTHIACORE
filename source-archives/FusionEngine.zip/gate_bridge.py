class GateBridge:
    pass
