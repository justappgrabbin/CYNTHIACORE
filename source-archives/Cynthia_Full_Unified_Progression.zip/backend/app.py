

# === SynthAI progression (freedoms + gnomes) ===
try:
    from modules.progression import load_state, save_state, level_up, combine, recalc_freedoms, can_customize
except Exception as e:
    print("Progression module load failed:", e)
    load_state = save_state = level_up = combine = recalc_freedoms = can_customize = None

@app.route("/progress/state")
def progress_state():
    if not load_state:
        return jsonify({"error":"progression module unavailable"}), 500
    p = load_state()
    recalc_freedoms(p)
    save_state(p)
    return jsonify({
        "days": int((time.time()-p.started_ts)//86400),
        "freedoms_tier": p.freedoms_tier,
        "can": {
            "skin": can_customize("skin", p),
            "city_layout": can_customize("city_layout", p),
            "avatar_reskin": can_customize("avatar_reskin", p),
            "companions": can_customize("companions", p),
            "composer": can_customize("composer", p),
        },
        "gnomes": {k: {"level": v.level, "element": v.element} for k,v in p.gnomes.items()},
        "forms": p.forms
    })

@app.route("/gnomes/levelup", methods=["POST"])
def gnomes_levelup():
    if not load_state:
        return jsonify({"error":"progression module unavailable"}), 500
    p = load_state()
    data = request.json or {}
    gid = int(data.get("id", 0))
    ok = level_up(gid, p)
    save_state(p)
    return jsonify({"success": ok, "gnome": gid, "tier": p.freedoms_tier})

@app.route("/gnomes/combine", methods=["POST"])
def gnomes_combine():
    if not load_state:
        return jsonify({"error":"progression module unavailable"}), 500
    p = load_state()
    data = request.json or {}
    ids = data.get("ids") or []
    form = combine(ids, p)
    save_state(p)
    return jsonify({"form": form})
