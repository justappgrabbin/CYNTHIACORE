
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from typing import Dict, List, Optional, Tuple, Any
import json, time, math, os, pathlib

STATE_PATH = pathlib.Path(__file__).resolve().parents[2] / "data" / "user_state.json"

# 64 gnomes with 3 levels (0..3). We group them by HD center for gating.
GNOME2CENTER: Dict[int, str] = {
    # simple mapping placeholder: distribute 64 gates across centers
    **{g: "head" for g in [61,63,64]},
    **{g: "ajna" for g in [47,24,11,4,17,43]},
    **{g: "throat" for g in [62,23,56,16,20,31,33,35,45,12]},
    **{g: "g" for g in [1,2,7,10,13,15,25,46]},
    **{g: "ego" for g in [21,26,40,51]},
    **{g: "solar" for g in [6,22,37,55,30,36,49]},
    **{g: "sacral" for g in [34,5,9,14,27,29,42,59,3]},
    **{g: "spleen" for g in [18,28,44,50,32,57]},
    **{g: "root" for g in [58,38,54,53,39,52,19,41]},
}

CENTER_ORDER = ["head","ajna","throat","g","ego","solar","sacral","spleen","root"]

@dataclass
class Gnome:
    id: int
    level: int = 0  # 0..3
    element: str = "ether"  # fire|water|air|earth|ether
    trait: str = "cognition"  # cognition|emotion|action

@dataclass
class Profile:
    started_ts: float
    quests: Dict[str, bool] = field(default_factory=dict)
    gnomes: Dict[int, Gnome] = field(default_factory=dict)  # id -> Gnome
    centers_active: Dict[str, bool] = field(default_factory=dict)  # computed externally via transits
    freedoms_tier: int = 0  # 0..5
    forms: List[Dict[str, Any]] = field(default_factory=list)  # combined forms

DEFAULT_THRESHOLDS = {
    0: {"min_days": 0,  "min_levels": 0},
    1: {"min_days": 14, "min_levels": 8},   # unlock skin pick
    2: {"min_days": 21, "min_levels": 16},  # unlock city layout
    3: {"min_days": 30, "min_levels": 24},  # unlock avatar reskin
    4: {"min_days": 45, "min_levels": 36},  # unlock companions (godmotachi)
    5: {"min_days": 60, "min_levels": 48},  # unlock multi-form composer
}

ELEMENT_FUSION = {
    # fusion matrix for two elements -> result
    ("fire","water"): "steam",
    ("fire","air"): "plasma",
    ("fire","earth"): "lava",
    ("water","air"): "mist",
    ("water","earth"): "mud",
    ("air","earth"): "dust",
    ("ether","fire"): "star",
    ("ether","water"): "wave",
    ("ether","air"): "aetheric",
    ("ether","earth"): "crystal",
}

def load_state() -> Profile:
    if STATE_PATH.exists():
        j = json.loads(STATE_PATH.read_text())
        g = {int(k): Gnome(**v) for k, v in j.get("gnomes",{}).items()}
        p = Profile(
            started_ts=j.get("started_ts", time.time()),
            quests=j.get("quests", {}),
            gnomes=g,
            centers_active=j.get("centers_active", {}),
            freedoms_tier=j.get("freedoms_tier", 0),
            forms=j.get("forms", []),
        )
        return p
    # init new profile
    gnomes = {gid: Gnome(id=gid, level=0, element=default_element_for(gid), trait=default_trait_for(gid)) for gid in sorted(GNOME2CENTER)}
    p = Profile(started_ts=time.time(), gnomes=gnomes, centers_active={c: False for c in CENTER_ORDER})
    save_state(p)
    return p

def save_state(profile: Profile) -> None:
    obj = asdict(profile)
    obj["gnomes"] = {k: asdict(v) for k,v in profile.gnomes.items()}
    STATE_PATH.write_text(json.dumps(obj, indent=2))

def days_since_start(profile: Profile) -> int:
    return int((time.time() - profile.started_ts) // 86400)

def total_levels(profile: Profile) -> int:
    return sum(g.level for g in profile.gnomes.values())

def recalc_freedoms(profile: Profile) -> int:
    days = days_since_start(profile)
    levels = total_levels(profile)
    tier = profile.freedoms_tier
    for t in sorted(DEFAULT_THRESHOLDS):
        th = DEFAULT_THRESHOLDS[t]
        if days >= th["min_days"] and levels >= th["min_levels"]:
            tier = max(tier, t)
    profile.freedoms_tier = tier
    return tier

def can_customize(feature: str, profile: Profile) -> bool:
    # feature -> min tier
    gates = {
        "skin": 1,
        "city_layout": 2,
        "avatar_reskin": 3,
        "companions": 4,
        "composer": 5,
    }
    need = gates.get(feature, 0)
    return profile.freedoms_tier >= need

def level_up(gnome_id: int, profile: Profile) -> bool:
    g = profile.gnomes.get(gnome_id)
    if not g: return False
    if g.level >= 3: return False
    g.level += 1
    recalc_freedoms(profile)
    return True

def default_element_for(gid: int) -> str:
    idx = gid % 5
    return ["fire","water","air","earth","ether"][idx]

def default_trait_for(gid: int) -> str:
    idx = gid % 3
    return ["cognition","emotion","action"][idx]

def combine(ids: List[int], profile: Profile) -> Dict[str, Any]:
    # combine 2-3 gnomes, produce a "form" with fused element & averaged level
    sel = [profile.gnomes[i] for i in ids if i in profile.gnomes]
    if len(sel) < 2: return {"error":"select at least two gnomes"}
    base = sel[0].element
    fused = base
    for g in sel[1:]:
        pair = tuple(sorted([fused, g.element]))
        fused = ELEMENT_FUSION.get(pair, fused if fused==g.element else "hybrid")
    lvl = sum(g.level for g in sel)/len(sel)
    form = {
        "id": f"form-{int(time.time())}",
        "gnomes": ids,
        "element": fused,
        "level": round(lvl,2),
        "center_bias": most_common([GNOME2CENTER[i] for i in ids])
    }
    profile.forms.append(form)
    return form

def most_common(xs: List[str]) -> str:
    from collections import Counter
    return Counter(xs).most_common(1)[0][0]
