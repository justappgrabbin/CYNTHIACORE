
const q = s=>document.querySelector(s), qa = s=>[...document.querySelectorAll(s)];
const CENTER_POS = {
  head:[50,8], ajna:[50,18], throat:[50,28], g:[50,42], ego:[62,38],
  solar:[75,55], sacral:[50,55], spleen:[25,55], root:[50,72]
}; // % positions over the avatar box

async function getState(){
  const r = await fetch('/progress/state'); return await r.json();
}
function placeDot(container, name, active, route){
  const d = document.createElement('div'); d.className = 'center-dot'+(active?'':' locked');
  const [x,y] = CENTER_POS[name];
  d.style.left = `calc(${x}% - 9px)`; d.style.top = `calc(${y}% - 9px)`;
  d.title = name;
  if(active){
    d.onclick = ()=> location.href = route || ('/district/'+name);
  }
  container.appendChild(d);
}
async function init(){
  const state = await getState();
  const overlay = q('#overlay'); const list = q('#centers');
  const centers = ['head','ajna','throat','g','ego','solar','sacral','spleen','root'];
  centers.forEach(c=>{
    const li = document.createElement('li'); const on = !!state?.centers_active?.[c];
    li.innerHTML = `<span>${c.toUpperCase()}</span><span class='badge'>${on?'ACTIVE':'LOCKED'}</span>`;
    list.appendChild(li);
    placeDot(overlay, c, on, {
      head:'/district/head', ajna:'/district/ajna', throat:'/district/throat',
      g:'/district/g', ego:'/district/ego', solar:'/district/solar', sacral:'/district/sacral',
      spleen:'/district/spleen', root:'/district/root'
    }[c]);
  });
  q('#gate').textContent = `Tier ${state.freedoms_tier} — ${state.can.skin?'Skin enabled':'Skin locked until Day 14 + levels'}`;
}
init();
