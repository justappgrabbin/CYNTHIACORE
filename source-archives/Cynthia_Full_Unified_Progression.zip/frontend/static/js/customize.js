async function loadJSON(url){ const r = await fetch(url); return await r.json(); }
const q = s=>document.querySelector(s), qa = s=>[...document.querySelectorAll(s)];
let skinsIndex = null, currentSkin = null, cities = null;
async function init(){
  skinsIndex = await loadJSON('/data/skins/index.json');
  cities = await loadJSON('/data/cities/default.json');
  const sel = q('#skinSelect');
  skinsIndex.skins.forEach((s)=>{ const o = document.createElement('option'); o.value = s.id; o.textContent = s.label; sel.appendChild(o); });
  sel.onchange = ()=> setSkin(sel.value);
  setSkin(localStorage.getItem('skin.id') || skinsIndex.skins[0].id);
  renderCities();
  q('#saveSkin').onclick = saveSkin;
  q('#exportCfg').onclick = exportCfg;
}
function setSkin(id){
  currentSkin = skinsIndex.skins.find(s=>s.id===id) || skinsIndex.skins[0];
  const {bg,primary,accent,ink,glow} = currentSkin.palette;
  q('#bg').value = toColor(bg); q('#primary').value = toColor(primary); q('#accent').value = toColor(accent);
  q('#ink').value = toColor(ink); q('#glow').value = toColor(glow);
  q('#gnomeStyle').value = currentSkin.gnomeStyle || 'gnomes';
  localStorage.setItem('skin.id', currentSkin.id);
  updatePreview();
}
function toColor(s){ try{ if(s.startsWith('#')) return s; }catch{} return '#a78bfa'; }
function updatePreview(){
  const a = q('#avatar'); a.style.background = currentSkin.palette.bg;
  a.querySelector('.overlay').textContent = (currentSkin.avatar.overlay==='hd')?'HD':'—';
}
function renderCities(){
  const root = q('#cities'); root.innerHTML = '';
  cities.cities.forEach(city=>{
    const c = document.createElement('div'); c.className='city';
    c.innerHTML = `<div class='row'><strong>${city.label}</strong><span class='badge'>${city.id}</span></div>`;
    city.districts.forEach(d=>{
      const row = document.createElement('div'); row.className='district';
      row.innerHTML = `<div>${d.label} <span class='badge'>${d.center}</span></div>
        <div class='row'><label class='badge'>Always ${d.alwaysAvailable?'On':'Off'}</label></div>`;
      c.appendChild(row);
    });
    root.appendChild(c);
  });
}
function saveSkin(){
  currentSkin.palette.bg = q('#bg').value;
  currentSkin.palette.primary = q('#primary').value;
  currentSkin.palette.accent = q('#accent').value;
  currentSkin.palette.ink = q('#ink').value;
  currentSkin.palette.glow = q('#glow').value;
  currentSkin.gnomeStyle = q('#gnomeStyle').value;
  localStorage.setItem('skin.custom', JSON.stringify(currentSkin));
  q('#status').textContent = 'Saved to this browser.';
}
function exportCfg(){
  const cfg = { skin: currentSkin, cities: cities };
  const blob = new Blob([JSON.stringify(cfg, null, 2)], {type:'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'config.json'; a.click();
}
init();
