/* Intercept ONLY the integrated core's localhost endpoints, keeping v14's
   Communication and other transport paths exactly as authored. */
(function(){
 const previous=window.fetch.bind(window);
 window.fetch=async function(input,options){
  const url=typeof input==='string'?input:input?.url??'';
  if(/^http:\/\/127\.0\.0\.1:8787\/api\//.test(url)){
   const endpoint=new URL(url).pathname;
   const body=options?.body?JSON.parse(options.body):{};
   try{
    const output=await window.SynthiaAndroidCore.handle(endpoint,body);
    return new Response(JSON.stringify(output),{status:200,headers:{'content-type':'application/json','access-control-allow-origin':'*'}});
   }catch(err){return new Response(JSON.stringify({ok:false,error:String(err?.message||err)}),{status:500,headers:{'content-type':'application/json'}})}
  }
  return previous(input,options);
 }
})();
