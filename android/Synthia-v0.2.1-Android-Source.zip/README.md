# Synthia v0.2.1 Android packaging

Android packaging of the user-provided `Synthia-Generative-Address-Morphology-Integrated-v0.2.1-RUNNABLE-2(1).zip` without changing the original v14 UI or the Synthia source logic.

This source project **is not an APK**. Build it with the GitHub Actions workflow or Android Gradle 8.6.1 / JDK 17 / Android SDK 35.

## Original source / adaption boundary

- `app/src/main/assets/synthia-v14-original.html` is byte-identical to the supplied `ui/synthia-v14-three-chat-modes.html`.
- `app/src/main/assets/index.html` is the same v14 UI with two support scripts inserted before the existing inline script. Its authored interface, menu, mode selector, and navigation are preserved.
- `synthia-core-bundle.js` is built by transpiling original Synthia modules to browser-loadable CommonJS module wrappers with TypeScript and introducing shims for Node crypto, path, and fs. The original modules are **not rewritten**.
- `android-fetch-bridge.js` only intercepts requests addressed to `http://127.0.0.1:8787/api/*` inside the app, dispatching to the local Synthia assembly in the WebView. Other network activity is not rewritten.
- Graph weights are stored in WebView localStorage under a source-path key. This is different from the original Node filesystem but persistent across launches; it does **not** preserve a separate original app's data or journal across reinstallations.
- This is a **local JS core**, not an external server or LLM.

## Verified in this environment

- Original core unit tests previously passed 51/51.
- A Node VM smoke test of `synthia-core-bundle.js` created the SynthiaGenerativeAssembly and returned distinct successful responses for Klein and Morph chat.
- No Android SDK or Gradle executable is available in the current offline container, and no physical-device test or produced APK is represented as completed.

## Known differences / limitations

- Other v14 Communication mode transports use their existing remote endpoints and API credentials; network failures or absent credentials remain visible.
- Browser-origin limitations, iframe loading, and Android WebView sandbox can affect third-party embedded sites; packaging does not certify the entire external service matrix.
- For locally embedded JS integration, the integrated CORE URL is intercepted only when it retains default 127.0.0.1:8787. Changing that CORE setting to another hostname intentionally uses the original network path.
- Package targetSdk is pinned to 28 for sideload compatibility of older v14 web features. Before Play Store distribution it must be updated and compatibility-tested.

## Build locally

Run `gradle assembleDebug` in this directory (with Android SDK 35 and JDK 17). APK expected at `app/build/outputs/apk/debug/app-debug.apk`.
